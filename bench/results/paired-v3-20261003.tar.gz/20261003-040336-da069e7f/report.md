# SQLite paired comparison

Comparison: inconclusive. Missing, failed, or tail-insufficient repetitions.

Win requires complete pairs, >=1000 samples per payload per repetition, and every concurrent broker p95/p99 below the best Doctrine repetition. Reverse separation is regression; overlapping ranges neutral; failures or insufficient tails inconclusive. No pooling.

Method revision: paired-v3-immediate. Do not combine captures from different revisions.

Doctrine transaction mode: immediate. Standard Doctrine transport; no custom empty-poll optimization. Broker writes remain serialized with immediate transactions.

Baseline status: incomplete. All scheduled runs, including warmup and failures, are retained.

Effective Xdebug mode: off. XDEBUG_MODE override: off. Compare only matching runtime profiles.

| Workload/run | Status | Metric, ms | n | p50 | p95 | p99 | max | Tail evidence |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| doctrine/roundtrip/warmup | complete | send_ms | 150 | 2.552 | 2.817 | 5.621 | 6.483 | inconclusive |
| doctrine/roundtrip/warmup | complete | publish_to_handler_ms | 150 | 6.475 | 6.825 | 10.615 | 11.848 | inconclusive |
| doctrine/roundtrip/warmup | complete | ack_ms | 150 | 1.926 | 2.957 | 3.841 | 4.243 | inconclusive |
| doctrine/roundtrip/warmup | complete | delivery_handling_ms | 150 | 2.049 | 3.030 | 3.994 | 4.385 | inconclusive |
| doctrine/roundtrip/warmup | complete | full_cycle_ms | 150 | 8.556 | 9.642 | 14.401 | 14.608 | inconclusive |
| doctrine/roundtrip/warmup | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/roundtrip/warmup | complete | confirmation_to_handler_ms | 150 | 3.925 | 4.189 | 5.366 | 7.124 | inconclusive |
| broker/roundtrip/warmup | complete | send_ms | 150 | 2.637 | 3.632 | 5.708 | 6.532 | inconclusive |
| broker/roundtrip/warmup | complete | publish_to_handler_ms | 150 | 5.702 | 7.664 | 10.162 | 10.822 | inconclusive |
| broker/roundtrip/warmup | complete | ack_ms | 150 | 2.743 | 3.027 | 4.752 | 5.956 | inconclusive |
| broker/roundtrip/warmup | complete | delivery_handling_ms | 150 | 2.868 | 3.084 | 4.962 | 6.017 | inconclusive |
| broker/roundtrip/warmup | complete | full_cycle_ms | 150 | 8.578 | 10.698 | 13.686 | 14.343 | inconclusive |
| broker/roundtrip/warmup | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/roundtrip/warmup | complete | confirmation_to_handler_ms | 150 | 3.072 | 4.132 | 5.114 | 6.081 | inconclusive |
| broker/roundtrip/run-1 | complete | send_ms | 150 | 2.639 | 3.636 | 5.605 | 6.326 | inconclusive |
| broker/roundtrip/run-1 | complete | publish_to_handler_ms | 150 | 5.685 | 7.560 | 9.835 | 10.726 | inconclusive |
| broker/roundtrip/run-1 | complete | ack_ms | 150 | 2.784 | 3.063 | 4.543 | 5.976 | inconclusive |
| broker/roundtrip/run-1 | complete | delivery_handling_ms | 150 | 2.887 | 3.126 | 4.697 | 6.040 | inconclusive |
| broker/roundtrip/run-1 | complete | full_cycle_ms | 150 | 8.598 | 10.653 | 13.549 | 14.532 | inconclusive |
| broker/roundtrip/run-1 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/roundtrip/run-1 | complete | confirmation_to_handler_ms | 150 | 3.054 | 3.996 | 5.122 | 6.284 | inconclusive |
| doctrine/roundtrip/run-1 | complete | send_ms | 150 | 2.579 | 2.767 | 5.569 | 9.576 | inconclusive |
| doctrine/roundtrip/run-1 | complete | publish_to_handler_ms | 150 | 6.557 | 6.923 | 10.731 | 21.416 | inconclusive |
| doctrine/roundtrip/run-1 | complete | ack_ms | 150 | 1.929 | 2.988 | 4.405 | 5.655 | inconclusive |
| doctrine/roundtrip/run-1 | complete | delivery_handling_ms | 150 | 2.048 | 3.054 | 4.571 | 5.800 | inconclusive |
| doctrine/roundtrip/run-1 | complete | full_cycle_ms | 150 | 8.617 | 9.899 | 14.719 | 24.442 | inconclusive |
| doctrine/roundtrip/run-1 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/roundtrip/run-1 | complete | confirmation_to_handler_ms | 150 | 3.979 | 4.297 | 7.023 | 11.840 | inconclusive |
| doctrine/roundtrip/run-2 | complete | send_ms | 150 | 2.560 | 2.701 | 4.958 | 5.557 | inconclusive |
| doctrine/roundtrip/run-2 | complete | publish_to_handler_ms | 150 | 6.580 | 6.778 | 9.712 | 11.620 | inconclusive |
| doctrine/roundtrip/run-2 | complete | ack_ms | 150 | 1.898 | 2.875 | 3.732 | 4.264 | inconclusive |
| doctrine/roundtrip/run-2 | complete | delivery_handling_ms | 150 | 2.015 | 2.933 | 3.937 | 4.472 | inconclusive |
| doctrine/roundtrip/run-2 | complete | full_cycle_ms | 150 | 8.597 | 9.604 | 14.184 | 15.557 | inconclusive |
| doctrine/roundtrip/run-2 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/roundtrip/run-2 | complete | confirmation_to_handler_ms | 150 | 3.980 | 4.211 | 6.062 | 7.189 | inconclusive |
| broker/roundtrip/run-2 | complete | send_ms | 150 | 2.660 | 3.592 | 4.912 | 5.627 | inconclusive |
| broker/roundtrip/run-2 | complete | publish_to_handler_ms | 150 | 5.734 | 7.725 | 8.749 | 10.695 | inconclusive |
| broker/roundtrip/run-2 | complete | ack_ms | 150 | 2.795 | 3.036 | 4.674 | 5.817 | inconclusive |
| broker/roundtrip/run-2 | complete | delivery_handling_ms | 150 | 2.893 | 3.102 | 4.868 | 5.876 | inconclusive |
| broker/roundtrip/run-2 | complete | full_cycle_ms | 150 | 8.658 | 11.025 | 13.601 | 13.617 | inconclusive |
| broker/roundtrip/run-2 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/roundtrip/run-2 | complete | confirmation_to_handler_ms | 150 | 3.102 | 4.185 | 5.068 | 6.194 | inconclusive |
| broker/roundtrip/run-3 | complete | send_ms | 150 | 2.668 | 3.616 | 5.555 | 7.028 | inconclusive |
| broker/roundtrip/run-3 | complete | publish_to_handler_ms | 150 | 5.705 | 7.713 | 10.698 | 11.489 | inconclusive |
| broker/roundtrip/run-3 | complete | ack_ms | 150 | 2.788 | 3.309 | 4.724 | 5.934 | inconclusive |
| broker/roundtrip/run-3 | complete | delivery_handling_ms | 150 | 2.898 | 3.443 | 4.877 | 5.989 | inconclusive |
| broker/roundtrip/run-3 | complete | full_cycle_ms | 150 | 8.629 | 11.352 | 13.549 | 14.931 | inconclusive |
| broker/roundtrip/run-3 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/roundtrip/run-3 | complete | confirmation_to_handler_ms | 150 | 3.071 | 4.172 | 5.143 | 5.980 | inconclusive |
| doctrine/roundtrip/run-3 | complete | send_ms | 150 | 2.574 | 2.793 | 5.015 | 5.612 | inconclusive |
| doctrine/roundtrip/run-3 | complete | publish_to_handler_ms | 150 | 5.693 | 6.819 | 10.678 | 11.504 | inconclusive |
| doctrine/roundtrip/run-3 | complete | ack_ms | 150 | 1.895 | 2.923 | 3.858 | 4.308 | inconclusive |
| doctrine/roundtrip/run-3 | complete | delivery_handling_ms | 150 | 1.955 | 3.035 | 4.006 | 4.455 | inconclusive |
| doctrine/roundtrip/run-3 | complete | full_cycle_ms | 150 | 7.680 | 9.701 | 14.338 | 14.684 | inconclusive |
| doctrine/roundtrip/run-3 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/roundtrip/run-3 | complete | confirmation_to_handler_ms | 150 | 3.058 | 4.200 | 7.107 | 7.465 | inconclusive |
| doctrine/concurrent/warmup | complete | send_ms | 3000 | 2.121 | 9.948 | 40.322 | 3836.015 | ok |
| doctrine/concurrent/warmup | complete | publish_to_handler_ms | 3000 | 10342.884 | 11859.926 | 12077.990 | 12542.969 | ok |
| doctrine/concurrent/warmup | complete | ack_ms | 3000 | 2.006 | 9.894 | 10.913 | 1331.795 | ok |
| doctrine/concurrent/warmup | complete | delivery_handling_ms | 3000 | 2.072 | 9.968 | 10.975 | 1331.957 | ok |
| doctrine/concurrent/warmup | complete | full_cycle_ms | 3000 | 10345.950 | 11865.917 | 12082.056 | 12965.964 | ok |
| doctrine/concurrent/warmup | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/concurrent/warmup | complete | confirmation_to_handler_ms | 3000 | 10332.997 | 11850.032 | 12069.899 | 12134.934 | ok |
| broker/concurrent/warmup | complete | send_ms | 3000 | 11.928 | 15.069 | 19.912 | 26.922 | ok |
| broker/concurrent/warmup | complete | publish_to_handler_ms | 3000 | 9247.819 | 9922.030 | 9980.082 | 9991.987 | ok |
| broker/concurrent/warmup | complete | ack_ms | 3000 | 4.748 | 13.865 | 16.969 | 20.869 | ok |
| broker/concurrent/warmup | complete | delivery_handling_ms | 3000 | 4.852 | 13.963 | 17.047 | 20.955 | ok |
| broker/concurrent/warmup | complete | full_cycle_ms | 3000 | 9251.757 | 9926.043 | 9984.779 | 9996.881 | ok |
| broker/concurrent/warmup | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/concurrent/warmup | complete | confirmation_to_handler_ms | 3000 | 9235.148 | 9910.859 | 9967.796 | 9980.898 | ok |
| broker/concurrent/run-1 | complete | send_ms | 3000 | 11.890 | 15.056 | 19.028 | 28.803 | ok |
| broker/concurrent/run-1 | complete | publish_to_handler_ms | 3000 | 9195.923 | 10215.127 | 10311.777 | 10329.721 | ok |
| broker/concurrent/run-1 | complete | ack_ms | 3000 | 4.785 | 13.747 | 17.655 | 29.709 | ok |
| broker/concurrent/run-1 | complete | delivery_handling_ms | 3000 | 4.898 | 13.880 | 17.824 | 29.889 | ok |
| broker/concurrent/run-1 | complete | full_cycle_ms | 3000 | 9200.915 | 10220.003 | 10315.983 | 10334.764 | ok |
| broker/concurrent/run-1 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/concurrent/run-1 | complete | confirmation_to_handler_ms | 3000 | 9184.987 | 10203.040 | 10298.915 | 10317.083 | ok |
| doctrine/concurrent/run-1 | incomplete | send_ms | 3000 | 2.061 | 10.083 | 14.945 | 3239.757 | ok |
| doctrine/concurrent/run-1 | incomplete | publish_to_handler_ms | 3000 | 7939.863 | 10203.914 | 10365.037 | 11375.611 | ok |
| doctrine/concurrent/run-1 | incomplete | ack_ms | 3000 | 1.875 | 9.776 | 10.788 | 3933.826 | ok |
| doctrine/concurrent/run-1 | incomplete | delivery_handling_ms | 3000 | 1.937 | 9.915 | 10.931 | 3933.860 | ok |
| doctrine/concurrent/run-1 | incomplete | full_cycle_ms | 3000 | 7943.430 | 10205.813 | 10367.007 | 11381.565 | ok |
| doctrine/concurrent/run-1 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/concurrent/run-1 | incomplete | confirmation_to_handler_ms | 3000 | 7932.906 | 10197.983 | 10359.133 | 10421.097 | ok |

Failure: consumer:1 exited with code 1; recorded operation failures

| doctrine/concurrent/run-2 | incomplete | send_ms | 3000 | 2.007 | 9.030 | 85.917 | 4833.166 | ok |
| doctrine/concurrent/run-2 | incomplete | publish_to_handler_ms | 3000 | 7740.925 | 9539.933 | 10020.934 | 10080.846 | ok |
| doctrine/concurrent/run-2 | incomplete | ack_ms | 3000 | 1.875 | 7.853 | 9.999 | 4834.703 | ok |
| doctrine/concurrent/run-2 | incomplete | delivery_handling_ms | 3000 | 1.933 | 7.986 | 10.046 | 4834.763 | ok |
| doctrine/concurrent/run-2 | incomplete | full_cycle_ms | 3000 | 7753.605 | 9543.951 | 10025.069 | 10082.775 | ok |
| doctrine/concurrent/run-2 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/concurrent/run-2 | incomplete | confirmation_to_handler_ms | 3000 | 7726.693 | 9537.975 | 10019.100 | 10078.977 | ok |

Failure: consumer:0 exited with code 1; recorded operation failures

| broker/concurrent/run-2 | complete | send_ms | 3000 | 11.900 | 15.029 | 19.140 | 399.949 | ok |
| broker/concurrent/run-2 | complete | publish_to_handler_ms | 3000 | 9517.868 | 10209.975 | 10287.924 | 10328.575 | ok |
| broker/concurrent/run-2 | complete | ack_ms | 3000 | 4.811 | 13.792 | 17.383 | 399.362 | ok |
| broker/concurrent/run-2 | complete | delivery_handling_ms | 3000 | 4.916 | 13.900 | 17.552 | 399.547 | ok |
| broker/concurrent/run-2 | complete | full_cycle_ms | 3000 | 9521.964 | 10214.902 | 10291.940 | 10334.482 | ok |
| broker/concurrent/run-2 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/concurrent/run-2 | complete | confirmation_to_handler_ms | 3000 | 9506.095 | 10195.885 | 10274.953 | 10315.009 | ok |
| broker/concurrent/run-3 | complete | send_ms | 3000 | 11.979 | 15.092 | 19.906 | 34.979 | ok |
| broker/concurrent/run-3 | complete | publish_to_handler_ms | 3000 | 9310.859 | 10277.031 | 10326.050 | 10334.909 | ok |
| broker/concurrent/run-3 | complete | ack_ms | 3000 | 4.825 | 13.774 | 17.321 | 26.815 | ok |
| broker/concurrent/run-3 | complete | delivery_handling_ms | 3000 | 4.917 | 13.892 | 17.393 | 26.879 | ok |
| broker/concurrent/run-3 | complete | full_cycle_ms | 3000 | 9314.766 | 10281.876 | 10330.769 | 10339.787 | ok |
| broker/concurrent/run-3 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/concurrent/run-3 | complete | confirmation_to_handler_ms | 3000 | 9297.902 | 10265.928 | 10312.931 | 10320.085 | ok |
| doctrine/concurrent/run-3 | complete | send_ms | 3000 | 2.052 | 9.999 | 59.918 | 4433.992 | ok |
| doctrine/concurrent/run-3 | complete | publish_to_handler_ms | 3000 | 9938.862 | 11695.938 | 12445.995 | 12555.859 | ok |
| doctrine/concurrent/run-3 | complete | ack_ms | 3000 | 2.014 | 9.890 | 10.858 | 4333.612 | ok |
| doctrine/concurrent/run-3 | complete | delivery_handling_ms | 3000 | 2.083 | 9.980 | 10.971 | 4333.753 | ok |
| doctrine/concurrent/run-3 | complete | full_cycle_ms | 3000 | 9940.798 | 11715.940 | 12455.044 | 15426.764 | ok |
| doctrine/concurrent/run-3 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/concurrent/run-3 | complete | confirmation_to_handler_ms | 3000 | 9932.862 | 11671.037 | 12439.896 | 12550.154 | ok |
| doctrine/many-to-one/warmup | complete | send_ms | 160 | 2.871 | 3.054 | 181.798 | 1034.367 | inconclusive |
| doctrine/many-to-one/warmup | complete | publish_to_handler_ms | 160 | 498.706 | 572.529 | 691.417 | 1136.002 | inconclusive |
| doctrine/many-to-one/warmup | complete | ack_ms | 160 | 1.860 | 2.859 | 6.070 | 6.756 | inconclusive |
| doctrine/many-to-one/warmup | complete | delivery_handling_ms | 160 | 1.924 | 2.903 | 6.103 | 6.905 | inconclusive |
| doctrine/many-to-one/warmup | complete | full_cycle_ms | 160 | 500.640 | 574.461 | 693.378 | 1137.880 | inconclusive |
| doctrine/many-to-one/warmup | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/many-to-one/warmup | complete | confirmation_to_handler_ms | 160 | 494.813 | 565.698 | 572.619 | 573.795 | inconclusive |
| broker/many-to-one/warmup | complete | send_ms | 160 | 11.941 | 12.932 | 17.883 | 17.965 | inconclusive |
| broker/many-to-one/warmup | complete | publish_to_handler_ms | 160 | 705.593 | 871.681 | 896.834 | 899.656 | inconclusive |
| broker/many-to-one/warmup | complete | ack_ms | 160 | 2.708 | 2.944 | 6.358 | 6.889 | inconclusive |
| broker/many-to-one/warmup | complete | delivery_handling_ms | 160 | 2.841 | 3.070 | 6.413 | 7.042 | inconclusive |
| broker/many-to-one/warmup | complete | full_cycle_ms | 160 | 708.447 | 878.724 | 899.819 | 901.596 | inconclusive |
| broker/many-to-one/warmup | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/many-to-one/warmup | complete | confirmation_to_handler_ms | 160 | 693.724 | 860.760 | 884.838 | 887.826 | inconclusive |
| broker/many-to-one/run-1 | complete | send_ms | 160 | 10.330 | 14.214 | 16.061 | 17.062 | inconclusive |
| broker/many-to-one/run-1 | complete | publish_to_handler_ms | 160 | 566.089 | 710.434 | 726.156 | 728.632 | inconclusive |
| broker/many-to-one/run-1 | complete | ack_ms | 160 | 1.771 | 2.885 | 3.430 | 4.843 | inconclusive |
| broker/many-to-one/run-1 | complete | delivery_handling_ms | 160 | 1.877 | 2.968 | 3.477 | 5.033 | inconclusive |
| broker/many-to-one/run-1 | complete | full_cycle_ms | 160 | 567.469 | 712.091 | 728.886 | 730.945 | inconclusive |
| broker/many-to-one/run-1 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/many-to-one/run-1 | complete | confirmation_to_handler_ms | 160 | 557.091 | 702.243 | 717.182 | 719.324 | inconclusive |
| doctrine/many-to-one/run-1 | complete | send_ms | 160 | 2.019 | 9.915 | 633.471 | 934.031 | inconclusive |
| doctrine/many-to-one/run-1 | complete | publish_to_handler_ms | 160 | 234.222 | 340.411 | 709.940 | 964.703 | inconclusive |
| doctrine/many-to-one/run-1 | complete | ack_ms | 160 | 1.816 | 8.782 | 9.872 | 9.964 | inconclusive |
| doctrine/many-to-one/run-1 | complete | delivery_handling_ms | 160 | 1.911 | 8.826 | 9.984 | 10.013 | inconclusive |
| doctrine/many-to-one/run-1 | complete | full_cycle_ms | 160 | 236.520 | 342.608 | 711.988 | 966.595 | inconclusive |
| doctrine/many-to-one/run-1 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/many-to-one/run-1 | complete | confirmation_to_handler_ms | 160 | 140.061 | 336.673 | 341.034 | 341.570 | inconclusive |
| doctrine/many-to-one/run-2 | complete | send_ms | 160 | 2.196 | 3.064 | 231.937 | 333.182 | inconclusive |
| doctrine/many-to-one/run-2 | complete | publish_to_handler_ms | 160 | 545.690 | 645.994 | 754.365 | 914.691 | inconclusive |
| doctrine/many-to-one/run-2 | complete | ack_ms | 160 | 1.865 | 2.171 | 4.497 | 6.057 | inconclusive |
| doctrine/many-to-one/run-2 | complete | delivery_handling_ms | 160 | 1.920 | 2.237 | 4.623 | 6.087 | inconclusive |
| doctrine/many-to-one/run-2 | complete | full_cycle_ms | 160 | 547.546 | 648.030 | 756.473 | 920.777 | inconclusive |
| doctrine/many-to-one/run-2 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/many-to-one/run-2 | complete | confirmation_to_handler_ms | 160 | 541.599 | 639.902 | 656.012 | 658.119 | inconclusive |
| broker/many-to-one/run-2 | complete | send_ms | 160 | 11.922 | 14.678 | 17.574 | 18.584 | inconclusive |
| broker/many-to-one/run-2 | complete | publish_to_handler_ms | 160 | 698.723 | 887.817 | 914.772 | 916.167 | inconclusive |
| broker/many-to-one/run-2 | complete | ack_ms | 160 | 2.759 | 2.930 | 6.749 | 6.825 | inconclusive |
| broker/many-to-one/run-2 | complete | delivery_handling_ms | 160 | 2.855 | 3.047 | 6.904 | 6.971 | inconclusive |
| broker/many-to-one/run-2 | complete | full_cycle_ms | 160 | 701.758 | 894.721 | 916.631 | 918.990 | inconclusive |
| broker/many-to-one/run-2 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/many-to-one/run-2 | complete | confirmation_to_handler_ms | 160 | 686.717 | 878.931 | 903.917 | 905.230 | inconclusive |
| broker/many-to-one/run-3 | complete | send_ms | 160 | 11.923 | 12.799 | 18.565 | 18.659 | inconclusive |
| broker/many-to-one/run-3 | complete | publish_to_handler_ms | 160 | 698.598 | 872.884 | 899.996 | 902.948 | inconclusive |
| broker/many-to-one/run-3 | complete | ack_ms | 160 | 2.709 | 2.997 | 7.008 | 7.219 | inconclusive |
| broker/many-to-one/run-3 | complete | delivery_handling_ms | 160 | 2.843 | 3.080 | 7.143 | 7.390 | inconclusive |
| broker/many-to-one/run-3 | complete | full_cycle_ms | 160 | 701.448 | 880.028 | 902.827 | 905.774 | inconclusive |
| broker/many-to-one/run-3 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/many-to-one/run-3 | complete | confirmation_to_handler_ms | 160 | 686.651 | 862.951 | 888.087 | 891.062 | inconclusive |
| doctrine/many-to-one/run-3 | complete | send_ms | 160 | 2.854 | 9.964 | 431.449 | 735.905 | inconclusive |
| doctrine/many-to-one/run-3 | complete | publish_to_handler_ms | 160 | 319.110 | 390.520 | 660.398 | 896.927 | inconclusive |
| doctrine/many-to-one/run-3 | complete | ack_ms | 160 | 1.876 | 2.916 | 5.879 | 81.345 | inconclusive |
| doctrine/many-to-one/run-3 | complete | delivery_handling_ms | 160 | 1.937 | 3.002 | 6.082 | 81.448 | inconclusive |
| doctrine/many-to-one/run-3 | complete | full_cycle_ms | 160 | 320.991 | 392.537 | 662.407 | 898.847 | inconclusive |
| doctrine/many-to-one/run-3 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/many-to-one/run-3 | complete | confirmation_to_handler_ms | 160 | 314.070 | 382.711 | 389.750 | 390.687 | inconclusive |
| doctrine/backlog/warmup | complete | send_ms | 240 | 2.823 | 3.027 | 4.637 | 8.973 | inconclusive |
| doctrine/backlog/warmup | complete | publish_to_handler_ms | 240 | 803.993 | 1273.645 | 1379.529 | 1397.505 | inconclusive |
| doctrine/backlog/warmup | complete | ack_ms | 240 | 1.863 | 2.092 | 4.020 | 5.845 | inconclusive |
| doctrine/backlog/warmup | complete | delivery_handling_ms | 240 | 1.929 | 2.129 | 4.081 | 5.965 | inconclusive |
| doctrine/backlog/warmup | complete | full_cycle_ms | 240 | 806.058 | 1275.540 | 1381.604 | 1399.597 | inconclusive |
| doctrine/backlog/warmup | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/backlog/warmup | complete | confirmation_to_handler_ms | 240 | 802.081 | 1270.641 | 1376.538 | 1394.615 | inconclusive |
| broker/backlog/warmup | complete | send_ms | 240 | 2.923 | 3.807 | 4.539 | 6.992 | inconclusive |
| broker/backlog/warmup | complete | publish_to_handler_ms | 240 | 967.703 | 1538.570 | 1655.611 | 1682.772 | inconclusive |
| broker/backlog/warmup | complete | ack_ms | 240 | 4.719 | 6.072 | 9.772 | 10.967 | inconclusive |
| broker/backlog/warmup | complete | delivery_handling_ms | 240 | 4.810 | 6.130 | 9.941 | 11.029 | inconclusive |
| broker/backlog/warmup | complete | full_cycle_ms | 240 | 971.593 | 1542.624 | 1659.785 | 1686.641 | inconclusive |
| broker/backlog/warmup | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/backlog/warmup | complete | confirmation_to_handler_ms | 240 | 964.555 | 1535.662 | 1652.691 | 1679.671 | inconclusive |
| broker/backlog/run-1 | complete | send_ms | 240 | 2.923 | 3.724 | 4.415 | 7.138 | inconclusive |
| broker/backlog/run-1 | complete | publish_to_handler_ms | 240 | 847.270 | 1342.700 | 1460.665 | 1487.462 | inconclusive |
| broker/backlog/run-1 | complete | ack_ms | 240 | 3.866 | 5.989 | 9.282 | 11.844 | inconclusive |
| broker/backlog/run-1 | complete | delivery_handling_ms | 240 | 4.002 | 6.059 | 9.343 | 11.910 | inconclusive |
| broker/backlog/run-1 | complete | full_cycle_ms | 240 | 850.018 | 1348.678 | 1465.521 | 1491.518 | inconclusive |
| broker/backlog/run-1 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/backlog/run-1 | complete | confirmation_to_handler_ms | 240 | 840.133 | 1339.781 | 1457.731 | 1484.625 | inconclusive |
| doctrine/backlog/run-1 | complete | send_ms | 240 | 2.109 | 3.042 | 5.746 | 9.921 | inconclusive |
| doctrine/backlog/run-1 | complete | publish_to_handler_ms | 240 | 829.638 | 1481.585 | 1655.583 | 1674.879 | inconclusive |
| doctrine/backlog/run-1 | complete | ack_ms | 240 | 1.915 | 9.792 | 10.970 | 11.168 | inconclusive |
| doctrine/backlog/run-1 | complete | delivery_handling_ms | 240 | 1.959 | 9.934 | 11.040 | 11.316 | inconclusive |
| doctrine/backlog/run-1 | complete | full_cycle_ms | 240 | 831.605 | 1486.999 | 1657.509 | 1677.603 | inconclusive |
| doctrine/backlog/run-1 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/backlog/run-1 | complete | confirmation_to_handler_ms | 240 | 826.778 | 1478.597 | 1652.723 | 1672.005 | inconclusive |
| doctrine/backlog/run-2 | complete | send_ms | 240 | 2.777 | 3.077 | 4.179 | 7.910 | inconclusive |
| doctrine/backlog/run-2 | complete | publish_to_handler_ms | 240 | 901.549 | 1371.449 | 1463.504 | 1481.634 | inconclusive |
| doctrine/backlog/run-2 | complete | ack_ms | 240 | 1.884 | 8.908 | 10.780 | 105.779 | inconclusive |
| doctrine/backlog/run-2 | complete | delivery_handling_ms | 240 | 1.933 | 8.959 | 10.835 | 105.903 | inconclusive |
| doctrine/backlog/run-2 | complete | full_cycle_ms | 240 | 903.660 | 1373.538 | 1465.371 | 1483.553 | inconclusive |
| doctrine/backlog/run-2 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/backlog/run-2 | complete | confirmation_to_handler_ms | 240 | 898.706 | 1368.616 | 1460.674 | 1478.793 | inconclusive |
| broker/backlog/run-2 | complete | send_ms | 240 | 2.922 | 3.104 | 3.889 | 6.960 | inconclusive |
| broker/backlog/run-2 | complete | publish_to_handler_ms | 240 | 928.709 | 1463.532 | 1577.656 | 1602.523 | inconclusive |
| broker/backlog/run-2 | complete | ack_ms | 240 | 3.973 | 5.806 | 10.054 | 11.003 | inconclusive |
| broker/backlog/run-2 | complete | delivery_handling_ms | 240 | 4.044 | 5.940 | 10.112 | 11.056 | inconclusive |
| broker/backlog/run-2 | complete | full_cycle_ms | 240 | 932.723 | 1467.582 | 1582.589 | 1606.595 | inconclusive |
| broker/backlog/run-2 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/backlog/run-2 | complete | confirmation_to_handler_ms | 240 | 925.685 | 1460.616 | 1574.662 | 1599.646 | inconclusive |
| broker/backlog/run-3 | complete | send_ms | 240 | 2.932 | 3.106 | 4.590 | 7.089 | inconclusive |
| broker/backlog/run-3 | complete | publish_to_handler_ms | 240 | 963.740 | 1533.752 | 1653.739 | 1682.676 | inconclusive |
| broker/backlog/run-3 | complete | ack_ms | 240 | 4.595 | 6.031 | 10.710 | 13.817 | inconclusive |
| broker/backlog/run-3 | complete | delivery_handling_ms | 240 | 4.784 | 6.087 | 10.905 | 13.946 | inconclusive |
| broker/backlog/run-3 | complete | full_cycle_ms | 240 | 967.716 | 1539.651 | 1659.693 | 1686.594 | inconclusive |
| broker/backlog/run-3 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| broker/backlog/run-3 | complete | confirmation_to_handler_ms | 240 | 960.615 | 1530.722 | 1650.815 | 1679.694 | inconclusive |
| doctrine/backlog/run-3 | complete | send_ms | 240 | 2.079 | 3.038 | 4.517 | 8.042 | inconclusive |
| doctrine/backlog/run-3 | complete | publish_to_handler_ms | 240 | 799.677 | 1270.776 | 1367.654 | 1386.617 | inconclusive |
| doctrine/backlog/run-3 | complete | ack_ms | 240 | 1.859 | 2.118 | 4.373 | 5.798 | inconclusive |
| doctrine/backlog/run-3 | complete | delivery_handling_ms | 240 | 1.916 | 2.218 | 4.519 | 5.948 | inconclusive |
| doctrine/backlog/run-3 | complete | full_cycle_ms | 240 | 801.579 | 1272.629 | 1369.565 | 1388.486 | inconclusive |
| doctrine/backlog/run-3 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| doctrine/backlog/run-3 | complete | confirmation_to_handler_ms | 240 | 796.640 | 1267.872 | 1364.799 | 1383.745 | inconclusive |
| doctrine/idle/warmup | complete | send_ms | 20 | 3.131 | 6.094 | 11.060 | 11.060 | inconclusive |
| doctrine/idle/warmup | complete | publish_to_handler_ms | 20 | 6.211 | 11.657 | 14.161 | 14.161 | inconclusive |
| doctrine/idle/warmup | complete | ack_ms | 20 | 2.712 | 2.915 | 2.984 | 2.984 | inconclusive |
| doctrine/idle/warmup | complete | delivery_handling_ms | 20 | 2.845 | 3.039 | 3.085 | 3.085 | inconclusive |
| doctrine/idle/warmup | complete | full_cycle_ms | 20 | 9.153 | 14.056 | 17.161 | 17.161 | inconclusive |
| doctrine/idle/warmup | complete | schedule_lag_ms | 20 | 0.127 | 0.150 | 0.156 | 0.156 | inconclusive |
| doctrine/idle/warmup | complete | confirmation_to_handler_ms | 20 | 3.177 | 5.102 | 5.563 | 5.563 | inconclusive |
| broker/idle/warmup | complete | send_ms | 20 | 6.016 | 20.876 | 29.977 | 29.977 | inconclusive |
| broker/idle/warmup | complete | publish_to_handler_ms | 20 | 9.882 | 23.877 | 32.939 | 32.939 | inconclusive |
| broker/idle/warmup | complete | ack_ms | 20 | 2.725 | 3.012 | 3.110 | 3.110 | inconclusive |
| broker/idle/warmup | complete | delivery_handling_ms | 20 | 2.892 | 3.139 | 3.279 | 3.279 | inconclusive |
| broker/idle/warmup | complete | full_cycle_ms | 20 | 12.770 | 26.769 | 35.856 | 35.856 | inconclusive |
| broker/idle/warmup | complete | schedule_lag_ms | 20 | 0.111 | 0.181 | 0.207 | 0.207 | inconclusive |
| broker/idle/warmup | complete | confirmation_to_handler_ms | 20 | 3.857 | 4.615 | 4.704 | 4.704 | inconclusive |
| broker/idle/run-1 | complete | send_ms | 20 | 16.946 | 43.270 | 105.199 | 105.199 | inconclusive |
| broker/idle/run-1 | complete | publish_to_handler_ms | 20 | 21.089 | 46.977 | 112.116 | 112.116 | inconclusive |
| broker/idle/run-1 | complete | ack_ms | 20 | 2.792 | 3.538 | 3.686 | 3.686 | inconclusive |
| broker/idle/run-1 | complete | delivery_handling_ms | 20 | 2.930 | 3.757 | 3.907 | 3.907 | inconclusive |
| broker/idle/run-1 | complete | full_cycle_ms | 20 | 24.846 | 50.044 | 114.971 | 114.971 | inconclusive |
| broker/idle/run-1 | complete | schedule_lag_ms | 20 | 0.140 | 0.180 | 5.419 | 5.419 | inconclusive |
| broker/idle/run-1 | complete | confirmation_to_handler_ms | 20 | 3.707 | 6.917 | 9.029 | 9.029 | inconclusive |
| doctrine/idle/run-1 | complete | send_ms | 20 | 2.421 | 6.276 | 6.553 | 6.553 | inconclusive |
| doctrine/idle/run-1 | complete | publish_to_handler_ms | 20 | 6.472 | 11.420 | 11.910 | 11.910 | inconclusive |
| doctrine/idle/run-1 | complete | ack_ms | 20 | 2.667 | 2.854 | 2.925 | 2.925 | inconclusive |
| doctrine/idle/run-1 | complete | delivery_handling_ms | 20 | 2.806 | 2.899 | 3.078 | 3.078 | inconclusive |
| doctrine/idle/run-1 | complete | full_cycle_ms | 20 | 9.287 | 14.235 | 14.324 | 14.324 | inconclusive |
| doctrine/idle/run-1 | complete | schedule_lag_ms | 20 | 0.138 | 0.176 | 0.177 | 0.177 | inconclusive |
| doctrine/idle/run-1 | complete | confirmation_to_handler_ms | 20 | 4.065 | 5.357 | 8.112 | 8.112 | inconclusive |
| doctrine/idle/run-2 | complete | send_ms | 20 | 3.989 | 30.918 | 31.012 | 31.012 | inconclusive |
| doctrine/idle/run-2 | complete | publish_to_handler_ms | 20 | 10.978 | 36.086 | 37.127 | 37.127 | inconclusive |
| doctrine/idle/run-2 | complete | ack_ms | 20 | 2.778 | 3.060 | 3.291 | 3.291 | inconclusive |
| doctrine/idle/run-2 | complete | delivery_handling_ms | 20 | 2.859 | 3.120 | 3.342 | 3.342 | inconclusive |
| doctrine/idle/run-2 | complete | full_cycle_ms | 20 | 14.040 | 39.040 | 39.935 | 39.935 | inconclusive |
| doctrine/idle/run-2 | complete | schedule_lag_ms | 20 | 0.138 | 0.150 | 0.238 | 0.238 | inconclusive |
| doctrine/idle/run-2 | complete | confirmation_to_handler_ms | 20 | 4.182 | 12.171 | 18.103 | 18.103 | inconclusive |
| broker/idle/run-2 | complete | send_ms | 20 | 3.703 | 43.645 | 70.652 | 70.652 | inconclusive |
| broker/idle/run-2 | complete | publish_to_handler_ms | 20 | 7.617 | 46.473 | 74.558 | 74.558 | inconclusive |
| broker/idle/run-2 | complete | ack_ms | 20 | 2.797 | 3.716 | 3.841 | 3.841 | inconclusive |
| broker/idle/run-2 | complete | delivery_handling_ms | 20 | 2.977 | 3.939 | 3.956 | 3.956 | inconclusive |
| broker/idle/run-2 | complete | full_cycle_ms | 20 | 10.458 | 49.499 | 77.628 | 77.628 | inconclusive |
| broker/idle/run-2 | complete | schedule_lag_ms | 20 | 0.139 | 0.178 | 0.191 | 0.191 | inconclusive |
| broker/idle/run-2 | complete | confirmation_to_handler_ms | 20 | 3.864 | 4.104 | 5.081 | 5.081 | inconclusive |
| broker/idle/run-3 | complete | send_ms | 20 | 5.509 | 31.566 | 45.580 | 45.580 | inconclusive |
| broker/idle/run-3 | complete | publish_to_handler_ms | 20 | 9.298 | 34.522 | 49.584 | 49.584 | inconclusive |
| broker/idle/run-3 | complete | ack_ms | 20 | 2.781 | 3.572 | 3.890 | 3.890 | inconclusive |
| broker/idle/run-3 | complete | delivery_handling_ms | 20 | 2.896 | 3.792 | 3.976 | 3.976 | inconclusive |
| broker/idle/run-3 | complete | full_cycle_ms | 20 | 12.283 | 37.345 | 52.448 | 52.448 | inconclusive |
| broker/idle/run-3 | complete | schedule_lag_ms | 20 | 0.139 | 0.177 | 0.202 | 0.202 | inconclusive |
| broker/idle/run-3 | complete | confirmation_to_handler_ms | 20 | 3.093 | 4.176 | 4.320 | 4.320 | inconclusive |
| doctrine/idle/run-3 | complete | send_ms | 20 | 4.987 | 12.095 | 13.000 | 13.000 | inconclusive |
| doctrine/idle/run-3 | complete | publish_to_handler_ms | 20 | 12.111 | 22.094 | 22.192 | 22.192 | inconclusive |
| doctrine/idle/run-3 | complete | ack_ms | 20 | 2.777 | 2.896 | 2.914 | 2.914 | inconclusive |
| doctrine/idle/run-3 | complete | delivery_handling_ms | 20 | 2.859 | 3.044 | 3.045 | 3.045 | inconclusive |
| doctrine/idle/run-3 | complete | full_cycle_ms | 20 | 15.021 | 24.969 | 25.077 | 25.077 | inconclusive |
| doctrine/idle/run-3 | complete | schedule_lag_ms | 20 | 0.138 | 0.151 | 0.154 | 0.154 | inconclusive |
| doctrine/idle/run-3 | complete | confirmation_to_handler_ms | 20 | 6.556 | 9.094 | 10.098 | 10.098 | inconclusive |
| doctrine/delayed/warmup | complete | send_ms | 40 | 2.424 | 3.347 | 5.581 | 5.581 | inconclusive |
| doctrine/delayed/warmup | complete | publish_to_handler_ms | 40 | 1541.575 | 1937.557 | 1981.602 | 1981.602 | inconclusive |
| doctrine/delayed/warmup | complete | ack_ms | 40 | 2.824 | 2.958 | 5.747 | 5.747 | inconclusive |
| doctrine/delayed/warmup | complete | delivery_handling_ms | 40 | 2.894 | 3.080 | 5.874 | 5.874 | inconclusive |
| doctrine/delayed/warmup | complete | full_cycle_ms | 40 | 1544.470 | 1940.413 | 1984.628 | 1984.628 | inconclusive |
| doctrine/delayed/warmup | complete | schedule_lag_ms | 40 | 0.116 | 0.175 | 0.177 | 0.177 | inconclusive |
| doctrine/delayed/warmup | complete | confirmation_to_handler_ms | 40 | 1539.131 | 1935.186 | 1979.092 | 1979.092 | inconclusive |
| doctrine/delayed/warmup | complete | delayed_lateness_ms | 40 | 60.949 | 117.875 | 125.027 | 125.027 | inconclusive |
| doctrine/delayed/warmup | complete | requested_deadline_lateness_ms | 40 | -458.425 | -62.443 | -18.398 | -18.398 | inconclusive |
| doctrine/delayed/warmup | complete | deadline_quantization_ms | 40 | -525.409 | -75.485 | -25.409 | -25.409 | inconclusive |
| broker/delayed/warmup | complete | send_ms | 40 | 2.929 | 4.047 | 5.990 | 5.990 | inconclusive |
| broker/delayed/warmup | complete | publish_to_handler_ms | 40 | 2003.933 | 2006.021 | 2009.867 | 2009.867 | inconclusive |
| broker/delayed/warmup | complete | ack_ms | 40 | 2.801 | 3.090 | 4.313 | 4.313 | inconclusive |
| broker/delayed/warmup | complete | delivery_handling_ms | 40 | 2.902 | 3.162 | 4.477 | 4.477 | inconclusive |
| broker/delayed/warmup | complete | full_cycle_ms | 40 | 2006.805 | 2009.762 | 2012.820 | 2012.820 | inconclusive |
| broker/delayed/warmup | complete | schedule_lag_ms | 40 | 0.125 | 0.163 | 0.208 | 0.208 | inconclusive |
| broker/delayed/warmup | complete | confirmation_to_handler_ms | 40 | 2000.935 | 2001.183 | 2006.954 | 2006.954 | inconclusive |
| broker/delayed/warmup | complete | delayed_lateness_ms | 40 | 4.023 | 6.165 | 9.937 | 9.937 | inconclusive |
| broker/delayed/warmup | complete | requested_deadline_lateness_ms | 40 | 3.932 | 6.021 | 9.867 | 9.867 | inconclusive |
| broker/delayed/warmup | complete | deadline_quantization_ms | 40 | -0.135 | -0.064 | -0.036 | -0.036 | inconclusive |
| broker/delayed/run-1 | complete | send_ms | 40 | 2.932 | 3.873 | 6.943 | 6.943 | inconclusive |
| broker/delayed/run-1 | complete | publish_to_handler_ms | 40 | 2003.830 | 2007.922 | 2013.974 | 2013.974 | inconclusive |
| broker/delayed/run-1 | complete | ack_ms | 40 | 2.789 | 3.239 | 4.285 | 4.285 | inconclusive |
| broker/delayed/run-1 | complete | delivery_handling_ms | 40 | 2.886 | 3.379 | 4.522 | 4.522 | inconclusive |
| broker/delayed/run-1 | complete | full_cycle_ms | 40 | 2006.738 | 2012.443 | 2016.784 | 2016.784 | inconclusive |
| broker/delayed/run-1 | complete | schedule_lag_ms | 40 | 0.128 | 0.189 | 0.214 | 0.214 | inconclusive |
| broker/delayed/run-1 | complete | confirmation_to_handler_ms | 40 | 2000.868 | 2003.992 | 2010.101 | 2010.101 | inconclusive |
| broker/delayed/run-1 | complete | delayed_lateness_ms | 40 | 4.018 | 8.178 | 14.129 | 14.129 | inconclusive |
| broker/delayed/run-1 | complete | requested_deadline_lateness_ms | 40 | 3.831 | 7.922 | 13.974 | 13.974 | inconclusive |
| broker/delayed/run-1 | complete | deadline_quantization_ms | 40 | -0.222 | -0.146 | -0.146 | -0.146 | inconclusive |
| doctrine/delayed/run-1 | complete | send_ms | 40 | 2.342 | 3.343 | 5.349 | 5.349 | inconclusive |
| doctrine/delayed/run-1 | complete | publish_to_handler_ms | 40 | 1522.359 | 1920.369 | 1964.413 | 1964.413 | inconclusive |
| doctrine/delayed/run-1 | complete | ack_ms | 40 | 2.771 | 2.994 | 3.012 | 3.012 | inconclusive |
| doctrine/delayed/run-1 | complete | delivery_handling_ms | 40 | 2.897 | 3.064 | 3.082 | 3.082 | inconclusive |
| doctrine/delayed/run-1 | complete | full_cycle_ms | 40 | 1525.288 | 1923.434 | 1967.288 | 1967.288 | inconclusive |
| doctrine/delayed/run-1 | complete | schedule_lag_ms | 40 | 0.120 | 0.170 | 0.176 | 0.176 | inconclusive |
| doctrine/delayed/run-1 | complete | confirmation_to_handler_ms | 40 | 1520.105 | 1917.978 | 1961.912 | 1961.912 | inconclusive |
| doctrine/delayed/run-1 | complete | delayed_lateness_ms | 40 | 39.846 | 105.838 | 117.941 | 117.941 | inconclusive |
| doctrine/delayed/run-1 | complete | requested_deadline_lateness_ms | 40 | -477.641 | -79.630 | -35.587 | -35.587 | inconclusive |
| doctrine/delayed/run-1 | complete | deadline_quantization_ms | 40 | -541.567 | -91.487 | -41.568 | -41.568 | inconclusive |
| doctrine/delayed/run-2 | complete | send_ms | 40 | 2.542 | 5.465 | 106.551 | 106.551 | inconclusive |
| doctrine/delayed/run-2 | complete | publish_to_handler_ms | 40 | 1550.553 | 1947.632 | 1992.727 | 1992.727 | inconclusive |
| doctrine/delayed/run-2 | complete | ack_ms | 40 | 2.778 | 2.942 | 3.099 | 3.099 | inconclusive |
| doctrine/delayed/run-2 | complete | delivery_handling_ms | 40 | 2.889 | 3.089 | 3.159 | 3.159 | inconclusive |
| doctrine/delayed/run-2 | complete | full_cycle_ms | 40 | 1553.490 | 1950.515 | 1995.557 | 1995.557 | inconclusive |
| doctrine/delayed/run-2 | complete | schedule_lag_ms | 40 | 0.139 | 0.216 | 56.725 | 56.725 | inconclusive |
| doctrine/delayed/run-2 | complete | confirmation_to_handler_ms | 40 | 1548.056 | 1900.970 | 1989.123 | 1989.123 | inconclusive |
| doctrine/delayed/run-2 | complete | delayed_lateness_ms | 40 | 47.802 | 104.814 | 116.951 | 116.951 | inconclusive |
| doctrine/delayed/run-2 | complete | requested_deadline_lateness_ms | 40 | -449.447 | -52.368 | -7.273 | -7.273 | inconclusive |
| doctrine/delayed/run-2 | complete | deadline_quantization_ms | 40 | -514.259 | -64.339 | -14.259 | -14.259 | inconclusive |
| broker/delayed/run-2 | complete | send_ms | 40 | 2.979 | 4.010 | 8.027 | 8.027 | inconclusive |
| broker/delayed/run-2 | complete | publish_to_handler_ms | 40 | 2004.002 | 2006.631 | 2008.129 | 2008.129 | inconclusive |
| broker/delayed/run-2 | complete | ack_ms | 40 | 2.776 | 3.314 | 4.222 | 4.222 | inconclusive |
| broker/delayed/run-2 | complete | delivery_handling_ms | 40 | 2.878 | 3.389 | 4.367 | 4.367 | inconclusive |
| broker/delayed/run-2 | complete | full_cycle_ms | 40 | 2006.872 | 2009.991 | 2012.497 | 2012.497 | inconclusive |
| broker/delayed/run-2 | complete | schedule_lag_ms | 40 | 0.105 | 0.178 | 0.348 | 0.348 | inconclusive |
| broker/delayed/run-2 | complete | confirmation_to_handler_ms | 40 | 2000.991 | 2002.430 | 2005.315 | 2005.315 | inconclusive |
| broker/delayed/run-2 | complete | delayed_lateness_ms | 40 | 3.988 | 6.573 | 8.837 | 8.837 | inconclusive |
| broker/delayed/run-2 | complete | requested_deadline_lateness_ms | 40 | 4.002 | 6.631 | 8.130 | 8.130 | inconclusive |
| broker/delayed/run-2 | complete | deadline_quantization_ms | 40 | 0.046 | 0.123 | 0.124 | 0.124 | inconclusive |
| broker/delayed/run-3 | complete | send_ms | 40 | 2.860 | 3.753 | 6.989 | 6.989 | inconclusive |
| broker/delayed/run-3 | complete | publish_to_handler_ms | 40 | 2003.840 | 2006.411 | 2009.847 | 2009.847 | inconclusive |
| broker/delayed/run-3 | complete | ack_ms | 40 | 2.780 | 3.124 | 4.345 | 4.345 | inconclusive |
| broker/delayed/run-3 | complete | delivery_handling_ms | 40 | 2.888 | 3.214 | 4.535 | 4.535 | inconclusive |
| broker/delayed/run-3 | complete | full_cycle_ms | 40 | 2006.720 | 2009.678 | 2013.060 | 2013.060 | inconclusive |
| broker/delayed/run-3 | complete | schedule_lag_ms | 40 | 0.147 | 0.198 | 0.214 | 0.214 | inconclusive |
| broker/delayed/run-3 | complete | confirmation_to_handler_ms | 40 | 2000.939 | 2001.177 | 2006.896 | 2006.896 | inconclusive |
| broker/delayed/run-3 | complete | delayed_lateness_ms | 40 | 3.933 | 6.533 | 9.883 | 9.883 | inconclusive |
| broker/delayed/run-3 | complete | requested_deadline_lateness_ms | 40 | 3.840 | 6.411 | 9.847 | 9.847 | inconclusive |
| broker/delayed/run-3 | complete | deadline_quantization_ms | 40 | -0.116 | -0.031 | -0.030 | -0.030 | inconclusive |
| doctrine/delayed/run-3 | complete | send_ms | 40 | 3.013 | 3.156 | 36.024 | 36.024 | inconclusive |
| doctrine/delayed/run-3 | complete | publish_to_handler_ms | 40 | 1547.070 | 1943.089 | 1987.085 | 1987.085 | inconclusive |
| doctrine/delayed/run-3 | complete | ack_ms | 40 | 2.799 | 2.991 | 3.028 | 3.028 | inconclusive |
| doctrine/delayed/run-3 | complete | delivery_handling_ms | 40 | 2.903 | 3.053 | 3.063 | 3.063 | inconclusive |
| doctrine/delayed/run-3 | complete | full_cycle_ms | 40 | 1550.133 | 1945.974 | 1989.951 | 1989.951 | inconclusive |
| doctrine/delayed/run-3 | complete | schedule_lag_ms | 40 | 0.138 | 0.183 | 0.193 | 0.193 | inconclusive |
| doctrine/delayed/run-3 | complete | confirmation_to_handler_ms | 40 | 1544.017 | 1940.036 | 1983.928 | 1983.928 | inconclusive |
| doctrine/delayed/run-3 | complete | delayed_lateness_ms | 40 | 38.815 | 107.825 | 118.871 | 118.871 | inconclusive |
| doctrine/delayed/run-3 | complete | requested_deadline_lateness_ms | 40 | -452.930 | -56.911 | -12.915 | -12.915 | inconclusive |
| doctrine/delayed/run-3 | complete | deadline_quantization_ms | 40 | -518.721 | -68.794 | -18.721 | -18.721 | inconclusive |

## Accounting by repetition

| Workload/run | Confirmed sends | ACKs | Unfinished | Failures | Handled/s | Sampled peak child processes | Sampled peak child RSS, KiB |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| doctrine/roundtrip/warmup | 150 | 150 | 0 | 0 | 116.45 | 2 | 96600 |
| broker/roundtrip/warmup | 150 | 150 | 0 | 0 | 107.52 | 5 | 190868 |
| broker/roundtrip/run-1 | 150 | 150 | 0 | 0 | 108.38 | 5 | 190604 |
| doctrine/roundtrip/run-1 | 150 | 150 | 0 | 0 | 111.77 | 2 | 96776 |
| doctrine/roundtrip/run-2 | 150 | 150 | 0 | 0 | 115.74 | 2 | 97028 |
| broker/roundtrip/run-2 | 150 | 150 | 0 | 0 | 105.42 | 5 | 190896 |
| broker/roundtrip/run-3 | 150 | 150 | 0 | 0 | 106.61 | 5 | 190636 |
| doctrine/roundtrip/run-3 | 150 | 150 | 0 | 0 | 117.41 | 2 | 96980 |
| doctrine/concurrent/warmup | 3000 | 3000 | 0 | 0 | 122.07 | 5 | 245116 |
| broker/concurrent/warmup | 3000 | 3000 | 0 | 0 | 141.95 | 8 | 347248 |
| broker/concurrent/run-1 | 3000 | 3000 | 0 | 0 | 140.39 | 8 | 345932 |
| doctrine/concurrent/run-1 | 3000 | 3000 | 0 | 1 | 135.89 | 5 | 253272 |
| doctrine/concurrent/run-2 | 3000 | 3000 | 0 | 1 | 152.81 | 5 | 246652 |
| broker/concurrent/run-2 | 3000 | 3000 | 0 | 0 | 138.41 | 8 | 347120 |
| broker/concurrent/run-3 | 3000 | 3000 | 0 | 0 | 139.19 | 8 | 347092 |
| doctrine/concurrent/run-3 | 3000 | 3000 | 0 | 0 | 119.36 | 5 | 243432 |
| doctrine/many-to-one/warmup | 160 | 160 | 0 | 0 | 184.75 | 5 | 236304 |
| broker/many-to-one/warmup | 160 | 160 | 0 | 0 | 180.94 | 8 | 332172 |
| broker/many-to-one/run-1 | 160 | 160 | 0 | 0 | 223.22 | 8 | 333376 |
| doctrine/many-to-one/run-1 | 160 | 160 | 0 | 0 | 155.65 | 5 | 236692 |
| doctrine/many-to-one/run-2 | 160 | 160 | 0 | 0 | 248.30 | 5 | 236528 |
| broker/many-to-one/run-2 | 160 | 160 | 0 | 0 | 176.93 | 8 | 332956 |
| broker/many-to-one/run-3 | 160 | 160 | 0 | 0 | 179.73 | 8 | 333840 |
| doctrine/many-to-one/run-3 | 160 | 160 | 0 | 0 | 154.86 | 5 | 236684 |
| doctrine/backlog/warmup | 240 | 240 | 0 | 0 | 241.20 | 3 | 143628 |
| broker/backlog/warmup | 240 | 240 | 0 | 0 | 195.54 | 6 | 238616 |
| broker/backlog/run-1 | 240 | 240 | 0 | 0 | 232.53 | 6 | 238296 |
| doctrine/backlog/run-1 | 240 | 240 | 0 | 0 | 188.21 | 3 | 143088 |
| doctrine/backlog/run-2 | 240 | 240 | 0 | 0 | 219.98 | 3 | 142852 |
| broker/backlog/run-2 | 240 | 240 | 0 | 0 | 210.27 | 6 | 238004 |
| broker/backlog/run-3 | 240 | 240 | 0 | 0 | 198.78 | 6 | 237876 |
| doctrine/backlog/run-3 | 240 | 240 | 0 | 0 | 241.65 | 3 | 143504 |
| doctrine/idle/warmup | 20 | 20 | 0 | 0 | 10.53 | 2 | 94644 |
| broker/idle/warmup | 20 | 20 | 0 | 0 | 10.53 | 5 | 189016 |
| broker/idle/run-1 | 20 | 20 | 0 | 0 | 10.37 | 5 | 189204 |
| doctrine/idle/run-1 | 20 | 20 | 0 | 0 | 10.54 | 2 | 94448 |
| doctrine/idle/run-2 | 20 | 20 | 0 | 0 | 10.52 | 2 | 95016 |
| broker/idle/run-2 | 20 | 20 | 0 | 0 | 10.53 | 5 | 189128 |
| broker/idle/run-3 | 20 | 20 | 0 | 0 | 10.52 | 5 | 188808 |
| doctrine/idle/run-3 | 20 | 20 | 0 | 0 | 10.52 | 2 | 94740 |
| doctrine/delayed/warmup | 41 | 41 | 0 | 0 | 36.69 | 2 | 95080 |
| broker/delayed/warmup | 41 | 41 | 0 | 0 | 21.04 | 5 | 189632 |
| broker/delayed/run-1 | 41 | 41 | 0 | 0 | 21.04 | 5 | 189372 |
| doctrine/delayed/run-1 | 41 | 41 | 0 | 0 | 19.75 | 2 | 95104 |
| doctrine/delayed/run-2 | 41 | 41 | 0 | 0 | 20.26 | 2 | 95672 |
| broker/delayed/run-2 | 41 | 41 | 0 | 0 | 21.04 | 5 | 188828 |
| broker/delayed/run-3 | 41 | 41 | 0 | 0 | 21.04 | 5 | 189156 |
| doctrine/delayed/run-3 | 41 | 41 | 0 | 0 | 19.84 | 2 | 95028 |

Raw samples, per-payload metrics, throughput, resource usage, polling, effective durability, configuration, and integrity counts are in summary.json and each repetition directory. No samples are trimmed or pooled across repetitions.
