# SQLite baseline

Baseline only. The candidate has not been measured. A/B comparison is incomplete.

Baseline status: incomplete. All scheduled runs, including warmup and failures, are retained.

| Workload/run | Status | Metric, ms | n | p50 | p95 | p99 | max | Tail evidence |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| roundtrip/warmup | complete | send_ms | 150 | 2.539 | 2.791 | 4.865 | 5.406 | inconclusive |
| roundtrip/warmup | complete | publish_to_handler_ms | 150 | 5.633 | 6.416 | 8.664 | 9.545 | inconclusive |
| roundtrip/warmup | complete | ack_ms | 150 | 2.409 | 2.921 | 3.728 | 4.285 | inconclusive |
| roundtrip/warmup | complete | delivery_handling_ms | 150 | 2.725 | 3.028 | 3.982 | 4.547 | inconclusive |
| roundtrip/warmup | complete | full_cycle_ms | 150 | 8.205 | 9.347 | 13.083 | 13.528 | inconclusive |
| roundtrip/warmup | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| roundtrip/warmup | complete | confirmation_to_handler_ms | 150 | 3.088 | 3.281 | 4.181 | 6.139 | inconclusive |
| roundtrip/run-1 | complete | send_ms | 150 | 2.502 | 2.952 | 5.364 | 5.459 | inconclusive |
| roundtrip/run-1 | complete | publish_to_handler_ms | 150 | 5.625 | 6.536 | 9.574 | 10.177 | inconclusive |
| roundtrip/run-1 | complete | ack_ms | 150 | 2.528 | 2.955 | 3.676 | 4.234 | inconclusive |
| roundtrip/run-1 | complete | delivery_handling_ms | 150 | 2.788 | 3.044 | 3.968 | 4.493 | inconclusive |
| roundtrip/run-1 | complete | full_cycle_ms | 150 | 8.373 | 9.385 | 13.434 | 13.542 | inconclusive |
| roundtrip/run-1 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| roundtrip/run-1 | complete | confirmation_to_handler_ms | 150 | 3.100 | 4.044 | 5.037 | 6.261 | inconclusive |
| roundtrip/run-2 | complete | send_ms | 150 | 2.528 | 3.139 | 5.076 | 5.559 | inconclusive |
| roundtrip/run-2 | complete | publish_to_handler_ms | 150 | 5.638 | 6.494 | 9.691 | 10.062 | inconclusive |
| roundtrip/run-2 | complete | ack_ms | 150 | 2.491 | 2.975 | 3.648 | 4.363 | inconclusive |
| roundtrip/run-2 | complete | delivery_handling_ms | 150 | 2.769 | 3.071 | 3.913 | 4.623 | inconclusive |
| roundtrip/run-2 | complete | full_cycle_ms | 150 | 8.339 | 9.414 | 13.079 | 13.604 | inconclusive |
| roundtrip/run-2 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| roundtrip/run-2 | complete | confirmation_to_handler_ms | 150 | 3.087 | 3.377 | 6.019 | 6.351 | inconclusive |
| roundtrip/run-3 | complete | send_ms | 150 | 2.508 | 2.762 | 4.714 | 5.305 | inconclusive |
| roundtrip/run-3 | complete | publish_to_handler_ms | 150 | 5.626 | 5.860 | 8.474 | 9.442 | inconclusive |
| roundtrip/run-3 | complete | ack_ms | 150 | 2.543 | 2.963 | 3.643 | 4.327 | inconclusive |
| roundtrip/run-3 | complete | delivery_handling_ms | 150 | 2.786 | 3.042 | 3.906 | 4.593 | inconclusive |
| roundtrip/run-3 | complete | full_cycle_ms | 150 | 8.359 | 8.744 | 13.067 | 13.348 | inconclusive |
| roundtrip/run-3 | complete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| roundtrip/run-3 | complete | confirmation_to_handler_ms | 150 | 3.073 | 3.278 | 4.137 | 6.068 | inconclusive |
| concurrent/warmup | incomplete | send_ms | 105 | 2.872 | 3.101 | 233.857 | 935.503 | inconclusive |
| concurrent/warmup | incomplete | publish_to_handler_ms | 100 | 444.596 | 523.481 | 531.557 | 554.329 | inconclusive |
| concurrent/warmup | incomplete | ack_ms | 100 | 1.988 | 2.953 | 7.492 | 331.085 | inconclusive |
| concurrent/warmup | incomplete | delivery_handling_ms | 100 | 2.069 | 3.043 | 7.857 | 331.233 | inconclusive |
| concurrent/warmup | incomplete | full_cycle_ms | 100 | 446.627 | 526.431 | 534.448 | 556.388 | inconclusive |
| concurrent/warmup | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| concurrent/warmup | incomplete | confirmation_to_handler_ms | 100 | 440.832 | 518.760 | 526.739 | 528.802 | inconclusive |

Failure: consumer:0 exited with code 1; consumer:1 exited with code 1; publisher:2 exited with code 1; recorded operation failures; RuntimeException: All consumers exited while publishing; observed 105 sends, workload defines 150; 45 of 150 sends were not confirmed; observed 100 ACKs, workload expects 150; 5 messages were never delivered; persisted work remains

| concurrent/run-1 | incomplete | send_ms | 11 | 2.898 | 84.119 | 84.119 | 84.119 | inconclusive |
| concurrent/run-1 | incomplete | publish_to_handler_ms | 1 | 13.540 | 13.540 | 13.540 | 13.540 | inconclusive |
| concurrent/run-1 | incomplete | ack_ms | 1 | 2.202 | 2.202 | 2.202 | 2.202 | inconclusive |
| concurrent/run-1 | incomplete | delivery_handling_ms | 1 | 2.340 | 2.340 | 2.340 | 2.340 | inconclusive |
| concurrent/run-1 | incomplete | full_cycle_ms | 1 | 15.881 | 15.881 | 15.881 | 15.881 | inconclusive |
| concurrent/run-1 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| concurrent/run-1 | incomplete | confirmation_to_handler_ms | 1 | 5.494 | 5.494 | 5.494 | 5.494 | inconclusive |

Failure: consumer:0 exited with code 1; consumer:1 exited with code 1; publisher:0 exited with code 1; publisher:1 exited with code 1; publisher:2 exited with code 1; recorded operation failures; RuntimeException: All consumers exited while publishing; observed 11 sends, workload defines 150; 139 of 150 sends were not confirmed; observed 1 ACKs, workload expects 150; 10 messages were never delivered; persisted work remains

| concurrent/run-2 | incomplete | send_ms | 6 | 7.809 | 38.504 | 38.504 | 38.504 | inconclusive |
| concurrent/run-2 | incomplete | publish_to_handler_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| concurrent/run-2 | incomplete | ack_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| concurrent/run-2 | incomplete | delivery_handling_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| concurrent/run-2 | incomplete | full_cycle_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| concurrent/run-2 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| concurrent/run-2 | incomplete | confirmation_to_handler_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |

Failure: consumer:0 exited with code 1; consumer:1 exited with code 1; publisher:0 exited with code 1; publisher:1 exited with code 1; publisher:2 exited with code 1; recorded operation failures; RuntimeException: All consumers exited while publishing; observed 6 sends, workload defines 150; 144 of 150 sends were not confirmed; observed 0 ACKs, workload expects 150; 6 messages were never delivered; persisted work remains

| concurrent/run-3 | incomplete | send_ms | 11 | 3.059 | 58.572 | 58.572 | 58.572 | inconclusive |
| concurrent/run-3 | incomplete | publish_to_handler_ms | 1 | 13.051 | 13.051 | 13.051 | 13.051 | inconclusive |
| concurrent/run-3 | incomplete | ack_ms | 1 | 2.194 | 2.194 | 2.194 | 2.194 | inconclusive |
| concurrent/run-3 | incomplete | delivery_handling_ms | 1 | 2.337 | 2.337 | 2.337 | 2.337 | inconclusive |
| concurrent/run-3 | incomplete | full_cycle_ms | 1 | 15.388 | 15.388 | 15.388 | 15.388 | inconclusive |
| concurrent/run-3 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| concurrent/run-3 | incomplete | confirmation_to_handler_ms | 1 | 5.594 | 5.594 | 5.594 | 5.594 | inconclusive |

Failure: consumer:0 exited with code 1; consumer:1 exited with code 1; publisher:0 exited with code 1; publisher:1 exited with code 1; publisher:2 exited with code 1; recorded operation failures; RuntimeException: All consumers exited while publishing; observed 11 sends, workload defines 150; 139 of 150 sends were not confirmed; observed 1 ACKs, workload expects 150; 10 messages were never delivered; persisted work remains

| many-to-one/warmup | incomplete | send_ms | 8 | 4.803 | 83.849 | 83.849 | 83.849 | inconclusive |
| many-to-one/warmup | incomplete | publish_to_handler_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/warmup | incomplete | ack_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/warmup | incomplete | delivery_handling_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/warmup | incomplete | full_cycle_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/warmup | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/warmup | incomplete | confirmation_to_handler_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |

Failure: consumer:0 exited with code 1; publisher:0 exited with code 1; publisher:1 exited with code 1; publisher:2 exited with code 1; publisher:3 exited with code 1; recorded operation failures; RuntimeException: All consumers exited while publishing; observed 8 sends, workload defines 160; 152 of 160 sends were not confirmed; observed 0 ACKs, workload expects 160; 8 messages were never delivered; persisted work remains

| many-to-one/run-1 | incomplete | send_ms | 8 | 5.451 | 55.800 | 55.800 | 55.800 | inconclusive |
| many-to-one/run-1 | incomplete | publish_to_handler_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-1 | incomplete | ack_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-1 | incomplete | delivery_handling_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-1 | incomplete | full_cycle_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-1 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-1 | incomplete | confirmation_to_handler_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |

Failure: consumer:0 exited with code 1; publisher:0 exited with code 1; publisher:1 exited with code 1; publisher:2 exited with code 1; publisher:3 exited with code 1; recorded operation failures; RuntimeException: All consumers exited while publishing; observed 8 sends, workload defines 160; 152 of 160 sends were not confirmed; observed 0 ACKs, workload expects 160; 8 messages were never delivered; persisted work remains

| many-to-one/run-2 | incomplete | send_ms | 10 | 10.119 | 59.571 | 59.571 | 59.571 | inconclusive |
| many-to-one/run-2 | incomplete | publish_to_handler_ms | 1 | 16.661 | 16.661 | 16.661 | 16.661 | inconclusive |
| many-to-one/run-2 | incomplete | ack_ms | 1 | 2.347 | 2.347 | 2.347 | 2.347 | inconclusive |
| many-to-one/run-2 | incomplete | delivery_handling_ms | 1 | 2.492 | 2.492 | 2.492 | 2.492 | inconclusive |
| many-to-one/run-2 | incomplete | full_cycle_ms | 1 | 19.154 | 19.154 | 19.154 | 19.154 | inconclusive |
| many-to-one/run-2 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-2 | incomplete | confirmation_to_handler_ms | 1 | 6.542 | 6.542 | 6.542 | 6.542 | inconclusive |

Failure: consumer:0 exited with code 1; publisher:0 exited with code 1; publisher:1 exited with code 1; publisher:2 exited with code 1; publisher:3 exited with code 1; recorded operation failures; RuntimeException: All consumers exited while publishing; observed 10 sends, workload defines 160; 150 of 160 sends were not confirmed; observed 1 ACKs, workload expects 160; 9 messages were never delivered; persisted work remains

| many-to-one/run-3 | incomplete | send_ms | 8 | 2.930 | 63.351 | 63.351 | 63.351 | inconclusive |
| many-to-one/run-3 | incomplete | publish_to_handler_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-3 | incomplete | ack_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-3 | incomplete | delivery_handling_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-3 | incomplete | full_cycle_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-3 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| many-to-one/run-3 | incomplete | confirmation_to_handler_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |

Failure: consumer:0 exited with code 1; publisher:0 exited with code 1; publisher:1 exited with code 1; publisher:2 exited with code 1; publisher:3 exited with code 1; recorded operation failures; RuntimeException: All consumers exited while publishing; observed 8 sends, workload defines 160; 152 of 160 sends were not confirmed; observed 0 ACKs, workload expects 160; 8 messages were never delivered; persisted work remains

| backlog/warmup | incomplete | send_ms | 240 | 2.721 | 3.083 | 4.580 | 7.711 | inconclusive |
| backlog/warmup | incomplete | publish_to_handler_ms | 240 | 911.021 | 1448.519 | 1573.401 | 1594.561 | inconclusive |
| backlog/warmup | incomplete | ack_ms | 240 | 1.879 | 2.682 | 4.308 | 5.818 | inconclusive |
| backlog/warmup | incomplete | delivery_handling_ms | 240 | 2.022 | 2.932 | 4.571 | 5.902 | inconclusive |
| backlog/warmup | incomplete | full_cycle_ms | 240 | 913.086 | 1450.373 | 1575.259 | 1597.351 | inconclusive |
| backlog/warmup | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| backlog/warmup | incomplete | confirmation_to_handler_ms | 240 | 908.701 | 1445.687 | 1570.668 | 1591.737 | inconclusive |

Failure: consumer:0 exited with code 1; recorded operation failures

| backlog/run-1 | incomplete | send_ms | 240 | 2.728 | 3.065 | 4.596 | 7.644 | inconclusive |
| backlog/run-1 | incomplete | publish_to_handler_ms | 240 | 917.989 | 1453.454 | 1572.336 | 1594.545 | inconclusive |
| backlog/run-1 | incomplete | ack_ms | 240 | 1.834 | 2.688 | 3.881 | 5.897 | inconclusive |
| backlog/run-1 | incomplete | delivery_handling_ms | 240 | 1.946 | 2.957 | 3.977 | 5.967 | inconclusive |
| backlog/run-1 | incomplete | full_cycle_ms | 240 | 920.019 | 1455.352 | 1574.200 | 1597.359 | inconclusive |
| backlog/run-1 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| backlog/run-1 | incomplete | confirmation_to_handler_ms | 240 | 916.082 | 1450.710 | 1569.676 | 1591.822 | inconclusive |

Failure: consumer:0 exited with code 1; recorded operation failures

| backlog/run-2 | incomplete | send_ms | 240 | 2.719 | 3.076 | 4.341 | 6.749 | inconclusive |
| backlog/run-2 | incomplete | publish_to_handler_ms | 240 | 909.504 | 1451.561 | 1569.544 | 1591.552 | inconclusive |
| backlog/run-2 | incomplete | ack_ms | 240 | 1.829 | 2.650 | 4.237 | 5.936 | inconclusive |
| backlog/run-2 | incomplete | delivery_handling_ms | 240 | 2.015 | 2.945 | 4.553 | 6.044 | inconclusive |
| backlog/run-2 | incomplete | full_cycle_ms | 240 | 911.548 | 1454.341 | 1571.565 | 1594.396 | inconclusive |
| backlog/run-2 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| backlog/run-2 | incomplete | confirmation_to_handler_ms | 240 | 906.743 | 1448.817 | 1565.318 | 1588.812 | inconclusive |

Failure: consumer:1 exited with code 1; recorded operation failures

| backlog/run-3 | incomplete | send_ms | 240 | 2.745 | 3.068 | 7.812 | 11.815 | inconclusive |
| backlog/run-3 | incomplete | publish_to_handler_ms | 240 | 938.589 | 1471.473 | 1588.490 | 1611.434 | inconclusive |
| backlog/run-3 | incomplete | ack_ms | 240 | 1.863 | 2.682 | 4.213 | 5.861 | inconclusive |
| backlog/run-3 | incomplete | delivery_handling_ms | 240 | 2.025 | 2.943 | 4.607 | 5.935 | inconclusive |
| backlog/run-3 | incomplete | full_cycle_ms | 240 | 941.388 | 1473.340 | 1591.272 | 1613.311 | inconclusive |
| backlog/run-3 | incomplete | schedule_lag_ms | 0 | n/a | n/a | n/a | n/a | inconclusive |
| backlog/run-3 | incomplete | confirmation_to_handler_ms | 240 | 935.799 | 1468.681 | 1585.803 | 1608.759 | inconclusive |

Failure: consumer:1 exited with code 1; recorded operation failures

| idle/warmup | complete | send_ms | 20 | 2.896 | 3.023 | 8.901 | 8.901 | inconclusive |
| idle/warmup | complete | publish_to_handler_ms | 20 | 6.007 | 7.087 | 13.470 | 13.470 | inconclusive |
| idle/warmup | complete | ack_ms | 20 | 2.741 | 2.791 | 2.811 | 2.811 | inconclusive |
| idle/warmup | complete | delivery_handling_ms | 20 | 2.871 | 3.008 | 3.038 | 3.038 | inconclusive |
| idle/warmup | complete | full_cycle_ms | 20 | 8.888 | 9.903 | 15.763 | 15.763 | inconclusive |
| idle/warmup | complete | schedule_lag_ms | 20 | 0.228 | 0.306 | 1.260 | 1.260 | inconclusive |
| idle/warmup | complete | confirmation_to_handler_ms | 20 | 3.078 | 4.242 | 4.569 | 4.569 | inconclusive |
| idle/run-1 | complete | send_ms | 20 | 5.818 | 14.093 | 17.985 | 17.985 | inconclusive |
| idle/run-1 | complete | publish_to_handler_ms | 20 | 9.196 | 17.124 | 21.127 | 21.127 | inconclusive |
| idle/run-1 | complete | ack_ms | 20 | 2.613 | 2.885 | 3.016 | 3.016 | inconclusive |
| idle/run-1 | complete | delivery_handling_ms | 20 | 2.865 | 2.982 | 3.130 | 3.130 | inconclusive |
| idle/run-1 | complete | full_cycle_ms | 20 | 11.878 | 20.064 | 23.967 | 23.967 | inconclusive |
| idle/run-1 | complete | schedule_lag_ms | 20 | 0.229 | 0.384 | 1.406 | 1.406 | inconclusive |
| idle/run-1 | complete | confirmation_to_handler_ms | 20 | 3.215 | 4.118 | 4.764 | 4.764 | inconclusive |
| idle/run-2 | complete | send_ms | 20 | 2.577 | 6.617 | 9.332 | 9.332 | inconclusive |
| idle/run-2 | complete | publish_to_handler_ms | 20 | 6.385 | 9.678 | 12.870 | 12.870 | inconclusive |
| idle/run-2 | complete | ack_ms | 20 | 2.623 | 3.020 | 3.072 | 3.072 | inconclusive |
| idle/run-2 | complete | delivery_handling_ms | 20 | 2.874 | 3.091 | 3.202 | 3.202 | inconclusive |
| idle/run-2 | complete | full_cycle_ms | 20 | 9.134 | 12.560 | 16.071 | 16.071 | inconclusive |
| idle/run-2 | complete | schedule_lag_ms | 20 | 0.212 | 0.368 | 1.523 | 1.523 | inconclusive |
| idle/run-2 | complete | confirmation_to_handler_ms | 20 | 3.116 | 4.084 | 5.414 | 5.414 | inconclusive |
| idle/run-3 | complete | send_ms | 20 | 3.075 | 3.295 | 5.310 | 5.310 | inconclusive |
| idle/run-3 | complete | publish_to_handler_ms | 20 | 6.231 | 7.325 | 10.296 | 10.296 | inconclusive |
| idle/run-3 | complete | ack_ms | 20 | 2.737 | 2.977 | 2.987 | 2.987 | inconclusive |
| idle/run-3 | complete | delivery_handling_ms | 20 | 2.873 | 3.053 | 3.054 | 3.054 | inconclusive |
| idle/run-3 | complete | full_cycle_ms | 20 | 9.079 | 10.175 | 13.149 | 13.149 | inconclusive |
| idle/run-3 | complete | schedule_lag_ms | 20 | 0.234 | 0.352 | 1.267 | 1.267 | inconclusive |
| idle/run-3 | complete | confirmation_to_handler_ms | 20 | 3.087 | 4.161 | 4.985 | 4.985 | inconclusive |
| delayed/warmup | complete | send_ms | 40 | 2.546 | 3.556 | 6.849 | 6.849 | inconclusive |
| delayed/warmup | complete | publish_to_handler_ms | 40 | 1557.444 | 1938.660 | 1981.457 | 1981.457 | inconclusive |
| delayed/warmup | complete | ack_ms | 40 | 2.717 | 3.273 | 3.680 | 3.680 | inconclusive |
| delayed/warmup | complete | delivery_handling_ms | 40 | 2.888 | 3.354 | 3.917 | 3.917 | inconclusive |
| delayed/warmup | complete | full_cycle_ms | 40 | 1560.326 | 1941.643 | 1984.372 | 1984.372 | inconclusive |
| delayed/warmup | complete | schedule_lag_ms | 40 | 0.191 | 0.302 | 1.999 | 1.999 | inconclusive |
| delayed/warmup | complete | confirmation_to_handler_ms | 40 | 1554.125 | 1936.087 | 1978.141 | 1978.141 | inconclusive |
| delayed/warmup | complete | delayed_lateness_ms | 40 | 60.963 | 122.988 | 133.991 | 133.991 | inconclusive |
| delayed/warmup | complete | requested_deadline_lateness_ms | 40 | -442.556 | -61.340 | -18.543 | -18.543 | inconclusive |
| delayed/warmup | complete | deadline_quantization_ms | 40 | -525.432 | -75.280 | -25.435 | -25.435 | inconclusive |
| delayed/run-1 | incomplete | send_ms | 37 | 3.066 | 3.340 | 5.026 | 5.026 | inconclusive |
| delayed/run-1 | incomplete | publish_to_handler_ms | 1 | 1746.128 | 1746.128 | 1746.128 | 1746.128 | inconclusive |
| delayed/run-1 | incomplete | ack_ms | 1 | 2.532 | 2.532 | 2.532 | 2.532 | inconclusive |
| delayed/run-1 | incomplete | delivery_handling_ms | 1 | 2.840 | 2.840 | 2.840 | 2.840 | inconclusive |
| delayed/run-1 | incomplete | full_cycle_ms | 1 | 1748.967 | 1748.967 | 1748.967 | 1748.967 | inconclusive |
| delayed/run-1 | incomplete | schedule_lag_ms | 37 | 0.197 | 0.400 | 1.260 | 1.260 | inconclusive |
| delayed/run-1 | incomplete | confirmation_to_handler_ms | 1 | 1741.102 | 1741.102 | 1741.102 | 1741.102 | inconclusive |
| delayed/run-1 | incomplete | delayed_lateness_ms | 1 | 4.082 | 4.082 | 4.082 | 4.082 | inconclusive |
| delayed/run-1 | incomplete | requested_deadline_lateness_ms | 1 | -253.872 | -253.872 | -253.872 | -253.872 | inconclusive |
| delayed/run-1 | incomplete | deadline_quantization_ms | 1 | -257.954 | -257.954 | -257.954 | -257.954 | inconclusive |

Failure: consumer:0 exited with code 1; prefill:0 exited with code 1; recorded operation failures; RuntimeException: All consumers exited while publishing; observed 37 sends, workload defines 41; 4 of 41 sends were not confirmed; observed 1 ACKs, workload expects 41; 36 messages were never delivered; persisted work remains

| delayed/run-2 | complete | send_ms | 40 | 2.673 | 3.459 | 81.578 | 81.578 | inconclusive |
| delayed/run-2 | complete | publish_to_handler_ms | 40 | 1539.621 | 1932.798 | 1976.650 | 1976.650 | inconclusive |
| delayed/run-2 | complete | ack_ms | 40 | 2.786 | 3.077 | 4.256 | 4.256 | inconclusive |
| delayed/run-2 | complete | delivery_handling_ms | 40 | 2.890 | 3.234 | 4.623 | 4.623 | inconclusive |
| delayed/run-2 | complete | full_cycle_ms | 40 | 1542.470 | 1935.688 | 1979.599 | 1979.599 | inconclusive |
| delayed/run-2 | complete | schedule_lag_ms | 40 | 0.225 | 0.391 | 31.851 | 31.851 | inconclusive |
| delayed/run-2 | complete | confirmation_to_handler_ms | 40 | 1537.079 | 1898.092 | 1974.042 | 1974.042 | inconclusive |
| delayed/run-2 | complete | delayed_lateness_ms | 40 | 54.864 | 112.836 | 124.899 | 124.899 | inconclusive |
| delayed/run-2 | complete | requested_deadline_lateness_ms | 40 | -460.379 | -67.202 | -23.349 | -23.349 | inconclusive |
| delayed/run-2 | complete | deadline_quantization_ms | 40 | -530.306 | -80.161 | -30.302 | -30.302 | inconclusive |
| delayed/run-3 | incomplete | send_ms | 40 | 3.085 | 3.320 | 11.195 | 11.195 | inconclusive |
| delayed/run-3 | incomplete | publish_to_handler_ms | 9 | 1681.325 | 1856.788 | 1856.788 | 1856.788 | inconclusive |
| delayed/run-3 | incomplete | ack_ms | 9 | 2.749 | 2.837 | 2.837 | 2.837 | inconclusive |
| delayed/run-3 | incomplete | delivery_handling_ms | 9 | 2.882 | 3.037 | 3.037 | 3.037 | inconclusive |
| delayed/run-3 | incomplete | full_cycle_ms | 9 | 1684.183 | 1859.038 | 1859.038 | 1859.038 | inconclusive |
| delayed/run-3 | incomplete | schedule_lag_ms | 40 | 0.188 | 0.312 | 1.286 | 1.286 | inconclusive |
| delayed/run-3 | incomplete | confirmation_to_handler_ms | 9 | 1678.143 | 1851.705 | 1851.705 | 1851.705 | inconclusive |
| delayed/run-3 | incomplete | delayed_lateness_ms | 9 | 26.940 | 50.926 | 50.926 | 50.926 | inconclusive |
| delayed/run-3 | incomplete | requested_deadline_lateness_ms | 9 | -318.676 | -143.211 | -143.211 | -143.211 | inconclusive |
| delayed/run-3 | incomplete | deadline_quantization_ms | 9 | -345.616 | -146.828 | -146.828 | -146.828 | inconclusive |

Failure: consumer:0 exited with code 1; prefill:0 exited with code 1; recorded operation failures; RuntimeException: All consumers exited while publishing; observed 40 sends, workload defines 41; 1 of 41 sends were not confirmed; observed 9 ACKs, workload expects 41; 31 messages were never delivered; persisted work remains


## Accounting by repetition

| Workload/run | Confirmed sends | ACKs | Unfinished | Failures | Handled/s | Sampled peak child processes | Sampled peak child RSS, KiB |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| roundtrip/warmup | 150 | 150 | 0 | 0 | 116.65 | 2 | 93664 |
| roundtrip/run-1 | 150 | 150 | 0 | 0 | 115.14 | 2 | 92724 |
| roundtrip/run-2 | 150 | 150 | 0 | 0 | 115.41 | 2 | 92992 |
| roundtrip/run-3 | 150 | 150 | 0 | 0 | 115.66 | 2 | 92912 |
| concurrent/warmup | 105 | 100 | 50 | 3 | 117.66 | 5 | 227428 |
| concurrent/run-1 | 11 | 1 | 149 | 5 | 427.30 | 5 | 225256 |
| concurrent/run-2 | 6 | 0 | 150 | 5 | n/a | 5 | 225336 |
| concurrent/run-3 | 11 | 1 | 149 | 5 | 427.87 | 5 | 224844 |
| many-to-one/warmup | 8 | 0 | 160 | 5 | n/a | 5 | 223728 |
| many-to-one/run-1 | 8 | 0 | 160 | 5 | n/a | 5 | 223624 |
| many-to-one/run-2 | 10 | 1 | 159 | 5 | 401.27 | 5 | 227092 |
| many-to-one/run-3 | 8 | 0 | 160 | 5 | n/a | 5 | 223640 |
| backlog/warmup | 240 | 240 | 0 | 1 | 204.25 | 3 | 135996 |
| backlog/run-1 | 240 | 240 | 0 | 1 | 204.11 | 3 | 136236 |
| backlog/run-2 | 240 | 240 | 0 | 1 | 204.27 | 3 | 136364 |
| backlog/run-3 | 240 | 240 | 0 | 1 | 203.22 | 3 | 136036 |
| idle/warmup | 20 | 20 | 0 | 0 | 10.55 | 2 | 91164 |
| idle/run-1 | 20 | 20 | 0 | 0 | 10.46 | 2 | 90608 |
| idle/run-2 | 20 | 20 | 0 | 0 | 10.55 | 2 | 91276 |
| idle/run-3 | 20 | 20 | 0 | 0 | 10.54 | 2 | 91332 |
| delayed/warmup | 41 | 41 | 0 | 0 | 19.23 | 2 | 90720 |
| delayed/run-1 | 37 | 1 | 40 | 2 | 352.15 | 2 | 91164 |
| delayed/run-2 | 41 | 41 | 0 | 0 | 20.31 | 2 | 91792 |
| delayed/run-3 | 40 | 9 | 32 | 2 | 179.19 | 2 | 91552 |

Raw samples, per-payload metrics, throughput, resource usage, polling, effective durability, configuration, and integrity counts are in summary.json and each repetition directory. No samples are trimmed or pooled across repetitions.
